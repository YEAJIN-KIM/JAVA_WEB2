package my.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import my.model.Book;

public class BookDao {

	public int insert (Connection conn, Book book) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement
			("insert into book (name, author, price) values (?,?,?)");
			pstmt.setString(1, book.getName());
			pstmt.setString(2, book.getAuthor());
			pstmt.setInt(3, book.getPrice());
			return pstmt.executeUpdate();
		} finally {
			pstmt.close();
		}
	}
	
	public int update (Connection conn, Book book) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement
			("update book set name=?, author=?, price=? where bookId=?");
			pstmt.setString(1, book.getName());
			pstmt.setString(2, book.getAuthor());
			pstmt.setInt(3, book.getPrice());
			pstmt.setInt(4, book.getBookId());
			return pstmt.executeUpdate();
		} finally {
			pstmt.close();
		}
	}
	
	
	public Book select (Connection conn, int bookId)throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("select * from book where bookId = ?");
			pstmt.setInt(1, bookId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return makeBookFromRS(rs);
			} else {
				return null;
			}
		}finally {
			pstmt.close();
			rs.close();
		}
	}
	public Book makeBookFromRS(ResultSet rs) throws SQLException {
		Book book = new Book();
		book.setBookId(rs.getInt("bookId"));//student�� �׸���� ä��
		book.setName(rs.getString("name"));
		book.setAuthor(rs.getString("author"));
		book.setPrice(rs.getInt("price"));
		
		return book;  //��������>return makeBookfromrs�ΰ��� �ٽ� �����ϸ� ����Ʈ���� ��ü���ҷ��´�
	}
	public int delete(Connection conn, int bookId) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement("delete from book where bookId = ?");
			pstmt.setInt(1, bookId);
			return pstmt.executeUpdate();
		} finally{
			pstmt.close();
		}
	}
}
	
	
	
	
	

