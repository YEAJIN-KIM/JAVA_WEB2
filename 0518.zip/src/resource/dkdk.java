package resource;

public class dkdk {

}
